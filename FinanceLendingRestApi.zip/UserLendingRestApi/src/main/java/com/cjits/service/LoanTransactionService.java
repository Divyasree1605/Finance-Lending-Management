package com.cjits.service;



import com.cjits.entity.LoanTransaction;

import java.util.List;

public interface LoanTransactionService {
    LoanTransaction createLoanTransaction(LoanTransaction loanTransaction);

    List<LoanTransaction> getAllLoanTransactions();

    LoanTransaction getLoanTransactionById(Long tranId);

    LoanTransaction updateLoanTransaction(Long tranId, LoanTransaction loanTransaction);

    void deleteLoanTransaction(Long tranId);
}

