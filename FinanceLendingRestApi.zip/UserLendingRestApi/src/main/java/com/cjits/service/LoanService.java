package com.cjits.service;

import com.cjits.entity.Loan;

import java.util.List;

public interface LoanService {
    public Loan createLoan(Loan loan);
    public List<Loan> getAllLoans();
    public Loan findLoanByloanId(long loanId) throws RuntimeException;
    public Loan findLoanByloantypes(Loan loan,long loanId) throws RuntimeException;
    public Loan updateLoan(Loan loan,long loanId) throws RuntimeException;
    public void deleteLoan(long loanId);
}

