package com.cjits.repository;

import com.cjits.entity.LoanRule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanRuleRepository extends JpaRepository<LoanRule,Long> {

}

