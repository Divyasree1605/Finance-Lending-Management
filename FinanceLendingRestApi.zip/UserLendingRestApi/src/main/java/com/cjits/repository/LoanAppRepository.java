package com.cjits.repository;

import com.cjits.entity.LoanApp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanAppRepository extends JpaRepository<LoanApp,Long> {
}
