package com.cjits.entity;

import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name="loans")
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long loanId;
    private double loan_amount;
    private String  loantypes;
    private double  loan_emis;
    private Date loan_start_date;
    private Date loan_due_date;

    public long getLoanId() {
        return loanId;
    }
    public void setLoanId(long loanId) {
        this.loanId = loanId;
    }

    public double getLoan_amount() {
        return loan_amount;
    }
    public void setLoan_amount(double loan_amount) {
        this.loan_amount = loan_amount;
    }
    public double getLoan_emis() {
        return loan_emis;
    }
    public void setLoan_emis(double loan_emi) {
        this.loan_emis = loan_emi;
    }
    public Date getLoan_start_date() {
        return loan_start_date;
    }
    public void setLoan_start_date(Date loan_start_date) {
        this.loan_start_date = loan_start_date;
    }
    public Date getLoan_due_date() {
        return loan_due_date;
    }
    public void setLoan_due_date(Date loan_due_date) {
        this.loan_due_date = loan_due_date;
    }
    @Override
    public String toString() {
        return loanId +
                ","+ loan_amount +
                ","+ loan_emis +
                "," + loan_start_date +
                "," + loan_due_date+
                ","+loantypes;
    }
    public String getLoantypes() {
        return loantypes;
    }
    public void setLoantypes(String loantypes) {
        this.loantypes = loantypes;
    }
}


