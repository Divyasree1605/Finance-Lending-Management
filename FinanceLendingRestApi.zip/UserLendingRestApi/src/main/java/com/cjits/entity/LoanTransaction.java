package com.cjits.entity;

import jakarta.persistence.*;


@Entity
@Table(name = "loantransaction")
public class LoanTransaction {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = " loan_tran_id")
    private Long tranId;
    @Column(name = " loan_installment")
    private String loanInstallment;
    @Column(name = " interest")
    private String interest;
    @Column(name = "penalty")
    private String penalty;
    @Column(name = "total_paid_amount")
    private String totalPaidAmount;
    @Column(name = "emi_date")
    private String emiDate;
    @Column(name = "due_date")
    private String dueDate;
    @Column(name = "balance_loan")
    private String balanceLoan;

    public LoanTransaction() {
    }

    public LoanTransaction(Long v, String loanInstallment, String interest, String penalty, String totalPaidAmount, String emiDate, String dueDate, String balanceLoan) {
        this.tranId = tranId;
        this.loanInstallment = loanInstallment;
        this.interest = interest;
        this.penalty = penalty;
        this.totalPaidAmount = totalPaidAmount;
        this.emiDate = emiDate;
        this.dueDate = dueDate;
        this.balanceLoan = balanceLoan;
    }

    public Long getId() {
        return tranId;
    }

    public void setId(Long id) {
        this.tranId = tranId;
    }

    public String getLoanInstallment() {
        return loanInstallment;
    }

    public void setLoanInstallment(String loanInstallment) {
        this.loanInstallment = loanInstallment;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getPenalty() {
        return penalty;
    }

    public void setPenalty(String penalty) {
        this.penalty = penalty;
    }

    public String getTotalPaidAmount() {
        return totalPaidAmount;
    }

    public void setTotalPaidAmount(String totalPaidAmount) {
        this.totalPaidAmount = totalPaidAmount;
    }

    public String getEmiDate() {
        return emiDate;
    }

    public void setEmiDate(String emiDate) {
        this.emiDate = emiDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getBalanceLoan() {
        return balanceLoan;
    }

    public void setBalanceLoan(String balanceLoan) {
        this.balanceLoan = balanceLoan;
    }
}
