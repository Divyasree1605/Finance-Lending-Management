package com.cjits.entity;

import jakarta.persistence.*;

@Entity
@Table(name="loanapp")
public class LoanApp {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long appId;
    private double loanAmount;
    private double emis;
    private String guarantor1;
    private String guarantor2;
    private String remarks;
    @ManyToOne
    @JoinColumn(name = "id")
    private User user;


    public LoanApp() {
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }



    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getEmis() {
        return emis;
    }

    public void setEmis(double emis) {
        this.emis = emis;
    }

    public String getGuarantor1() {
        return guarantor1;
    }

    public void setGuarantor1(String guarantor1) {
        this.guarantor1 = guarantor1;
    }

    public String getGuarantor2() {
        return guarantor2;
    }

    public void setGuarantor2(String guarantor2) {
        this.guarantor2 = guarantor2;
    }



    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "LoanApplication{" +
                "appId=" + appId +
                ", loanAmount=" + loanAmount +
                ", emis=" + emis +
                ", guarantor1='" + guarantor1 + '\'' +
                ", guarantor2='" + guarantor2 + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
