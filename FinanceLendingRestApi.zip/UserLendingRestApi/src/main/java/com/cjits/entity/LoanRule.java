package com.cjits.entity;

import jakarta.persistence.*;


@Entity
@Table(name = "loanrule")

public class LoanRule {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long loan_rid;
    @Column(name = "loan_type")
    private String loanType;
    @Column(name = "loan_roi")
    private String loanRoi;
    @Column(name = "loan_max_emi")
    private String loanMaxEmi;
    @Column(name = "loan_penalty")
    private String loanPenalty;

    public LoanRule() {

    }

    public LoanRule(long loan_rid, String loanType, String loanRoi, String loanMaxEmi, String loanPenalty) {
        this.loan_rid = loan_rid;
        this.loanType = loanType;
        this.loanRoi = loanRoi;
        this.loanMaxEmi = loanMaxEmi;
        this.loanPenalty = loanPenalty;
    }

    public long getLoan_rid() {
        return loan_rid;
    }

    public void setLoan_rid(long loan_rid) {
        this.loan_rid = loan_rid;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getLoanRoi() {
        return loanRoi;
    }

    public void setLoanRoi(String loanRoi) {
        this.loanRoi = loanRoi;
    }

    public String getLoanMaxEmi() {
        return loanMaxEmi;
    }

    public void setLoanMaxEmi(String loanMaxEmi) {
        this.loanMaxEmi = loanMaxEmi;
    }

    public String getLoanPenalty() {
        return loanPenalty;
    }

    public void setLoanPenalty(String loanPenalty) {
        this.loanPenalty = loanPenalty;
    }

    @Override
    public String toString() {
        return "LoanRule{" +
                "loan_rid=" + loan_rid +
                ", loanType='" + loanType + '\'' +
                ", loanRoi='" + loanRoi + '\'' +
                ", loanMaxEmi='" + loanMaxEmi + '\'' +
                ", loanPenalty='" + loanPenalty + '\'' +
                '}';
    }
}

