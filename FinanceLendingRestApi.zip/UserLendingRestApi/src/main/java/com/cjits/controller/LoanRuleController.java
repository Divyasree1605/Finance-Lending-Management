package com.cjits.controller;

import com.cjits.entity.LoanRule;
import com.cjits.service.LoanRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;



@RestController
@RequestMapping("/restapi/loanrule")
public class LoanRuleController {
    Logger logger = Logger.getLogger(this.getClass().getName());
    @Autowired
    private LoanRuleService service;

    //1. Create REST API
    @PostMapping
    public ResponseEntity<LoanRule> saveLoanRule(@RequestBody LoanRule l) {
        logger.warning("printing : " + l);
        return new ResponseEntity<LoanRule>(service.saveLoanRule(l), HttpStatus.CREATED);
    }

    //2. Get REST API
    @GetMapping
    public List<LoanRule> getAllLoanRules() {
        return service.getAllLoanRules();
    }

    //3. Get REST API by id
    @GetMapping("{loan_rid}")
    public ResponseEntity<LoanRule> getLoanRule(@PathVariable("loan_rid") String loan_rid) throws RuntimeException {
        return new ResponseEntity<LoanRule>(service.findLoanRuleById(Long.parseLong(loan_rid)), HttpStatus.OK);
    }

    //4. Update REST API
    @PutMapping("{loan_rid}")
    public ResponseEntity<LoanRule> updateLoanRule(@RequestBody LoanRule admin, @PathVariable("loan_rid") String loan_rid) throws RuntimeException {
        return new ResponseEntity<LoanRule>(service.UpdateLoanRule(admin, Long.parseLong(loan_rid)), HttpStatus.OK);
    }

    //5. Delete REST API
    @DeleteMapping("{loan_rid}")
    public ResponseEntity<String> deleteLoanRule(@PathVariable("loan_rid") String loan_rid) {
        service.deleteLoanRule(Long.parseLong(loan_rid));
        return new ResponseEntity<String>("Deleted", HttpStatus.OK);
    }
}
