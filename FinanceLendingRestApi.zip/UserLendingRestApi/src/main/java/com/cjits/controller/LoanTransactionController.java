package com.cjits.controller;

import com.cjits.entity.LoanTransaction;
import com.cjits.service.LoanTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restapi/loantransactions")
public class LoanTransactionController {

    private final LoanTransactionService loanTransactionService;

    @Autowired
    public LoanTransactionController(LoanTransactionService loanTransactionService) {
        this.loanTransactionService = loanTransactionService;
    }

    @PostMapping
    public ResponseEntity<LoanTransaction> createLoanTransaction(@RequestBody LoanTransaction loanTransaction) {
        LoanTransaction createdLoanTransaction = loanTransactionService.createLoanTransaction(loanTransaction);
        return new ResponseEntity<>(createdLoanTransaction, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<LoanTransaction>> getAllLoanTransactions() {
        List<LoanTransaction> loanTransactions = loanTransactionService.getAllLoanTransactions();
        return new ResponseEntity<>(loanTransactions, HttpStatus.OK);
    }

    @GetMapping("/{tranId}")
    public ResponseEntity<LoanTransaction> getLoanTransactionById(@PathVariable Long tranId) {
        LoanTransaction loanTransaction = loanTransactionService.getLoanTransactionById(tranId);
        if (loanTransaction != null) {
            return new ResponseEntity<>(loanTransaction, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{tranId}")
    public ResponseEntity<LoanTransaction> updateLoanTransaction(@PathVariable Long tranId,
                                                                 @RequestBody LoanTransaction loanTransaction) {
        LoanTransaction updatedLoanTransaction = loanTransactionService.updateLoanTransaction(tranId, loanTransaction);
        if (updatedLoanTransaction != null) {
            return new ResponseEntity<>(updatedLoanTransaction, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{tranId}")
    public ResponseEntity<Void> deleteLoanTransaction(@PathVariable Long tranId) {
        loanTransactionService.deleteLoanTransaction(tranId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

