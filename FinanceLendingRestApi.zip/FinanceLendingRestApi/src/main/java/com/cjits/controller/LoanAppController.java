package com.cjits.controller;

import com.cjits.entity.LoanApp;
import com.cjits.service.LoanAppServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/restapi/loanApps")
public class LoanAppController {
    @Autowired
    private LoanAppServiceImpl loanAppService;
    @GetMapping
    public ResponseEntity<List<LoanApp>> getAllLoanApp() {
        return ResponseEntity.ok(loanAppService.getAllLoanApp());
    }
    @GetMapping("/{appId}")
    public ResponseEntity<?> getLoanAppById(@PathVariable Long appId) {
        Optional<LoanApp> loanApp = loanAppService.getLoanAppById(appId);
        if (loanApp.isPresent()) {
            return ResponseEntity.ok(loanApp.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Loan Application with ID " + appId + " not found");
        }
    }
    @PostMapping
    public ResponseEntity<LoanApp> createLoanApp(@RequestBody LoanApp loanApp) {
        LoanApp newLoanApp = loanAppService.createLoanApp(loanApp);
        return ResponseEntity.ok(newLoanApp);
    }
    @PutMapping("/{appId}")
    public ResponseEntity<LoanApp> updateLoanApp(@PathVariable Long appId, @RequestBody LoanApp loanApp) {
        try {
            LoanApp updatedLoanApp = loanAppService.updateLoanApp(appId, loanApp);
            return ResponseEntity.ok(updatedLoanApp);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping("/loanApp/save")
    public ResponseEntity< ? > save(@RequestBody LoanApp loanApp) {
        Map< String, Object > respLoanApp = new LinkedHashMap< String, Object >();
        // saving loan application into db
        loanAppService.save(loanApp);
        respLoanApp.put("status", 1);
        respLoanApp.put("message", "Record is Saved Successfully!");
        return new ResponseEntity < > (respLoanApp, HttpStatus.CREATED);
    }
    @GetMapping("/loanApp/list")
    public ResponseEntity < ? > getLoanApp() {
        Map < String, Object > respLoanApp = new LinkedHashMap < String, Object > ();
        List< LoanApp > loanAppList = loanAppService.findLoanAppList();
        if (!loanAppList.isEmpty()) {
            respLoanApp.put("status", 1);
            respLoanApp.put("data", loanAppList);
            return new ResponseEntity < > (respLoanApp, HttpStatus.OK);
        } else {
            respLoanApp.clear();
            respLoanApp.put("status", 0);
            respLoanApp.put("message", "Data is not found");
            return new ResponseEntity < > (respLoanApp, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{appId}")
    public ResponseEntity<String> deleteLoanApp(@PathVariable Long appId) {
        loanAppService.deleteLoanApp(appId);
        return new ResponseEntity<String>("Deleted successfully", HttpStatus.OK);

    }
}
