package com.cjits.controller;
import com.cjits.entity.User;
import com.cjits.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/restapi/users")
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.getUserById(id);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User with ID " + id + " not found");
        }
    }


    @GetMapping("/username/{username}")
    public ResponseEntity<User> getUserByUsername(@PathVariable String username) {
        Optional<User> user = userService.getUserByUsername(username);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/usertype/{usertype}")
    public ResponseEntity<User> getUserByUsertype(@PathVariable String usertype) {
        Optional<User> user = userService.getUserByUsertype(usertype);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User newUser = userService.createuser(user);
        return ResponseEntity.ok(newUser);
    }
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User updatedUser = userService.updateUser(id, user);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping("/user/save")
    public ResponseEntity< ? > save(@RequestBody User user) {
        Map< String, Object > respUser = new LinkedHashMap< String, Object >();
        // saving Post into db
        userService.save(user);
        respUser.put("status", 1);
        respUser.put("message", "Record is Saved Successfully!");
        return new ResponseEntity < > (respUser, HttpStatus.CREATED);
    }
    @GetMapping("/post/list")
    public ResponseEntity < ? > getUsers() {
        Map < String, Object > respUser = new LinkedHashMap < String, Object > ();
        List< User > userList = userService.findUserList();
        if (!userList.isEmpty()) {
            respUser.put("status", 1);
            respUser.put("data", userList);
            return new ResponseEntity < > (respUser, HttpStatus.OK);
        } else {
            respUser.clear();
            respUser.put("status", 0);
            respUser.put("message", "Data is not found");
            return new ResponseEntity < > (respUser, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return new ResponseEntity<String>("Deleted successfully", HttpStatus.OK);

    }
}
