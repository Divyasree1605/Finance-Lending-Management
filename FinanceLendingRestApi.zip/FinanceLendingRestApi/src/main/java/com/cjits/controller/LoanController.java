
package com.cjits.controller;

import com.cjits.entity.Loan;
import com.cjits.service.LoanServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

    @RestController
    @RequestMapping("/restapi/loan")
    public class LoanController {
        @Autowired
        private LoanServiceImpl loanService;
        @GetMapping
        public ResponseEntity<List<Loan>> getAllLoans() {
            return ResponseEntity.ok(loanService.getAllLoans());
        }

        @GetMapping("/{loanId}")
        public ResponseEntity<?> getLoanById(@PathVariable Long loanId) {
            Optional<Loan> loan = loanService.getLoanById(loanId);
            if (loan.isPresent()) {
                return ResponseEntity.ok(loan.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Loan with ID " + loanId + " not found");
            }
        }


        @GetMapping("/loantypes/{loantypes}")
        public ResponseEntity<Loan> getLoanByLoantype(@PathVariable String loantypes) {
            Optional<Loan> loan = loanService.getLoanByLoantype(loantypes);
            if (loan.isPresent()) {
                return ResponseEntity.ok(loan.get());
            } else {
                return ResponseEntity.notFound().build();
            }
        }
        @PostMapping
        public ResponseEntity<Loan> createUser(@RequestBody Loan loan) {
            Loan newLoan = loanService.createLoan(loan);
            return ResponseEntity.ok(newLoan);
        }
        @PutMapping("/{loanId}")
        public ResponseEntity<Loan> updateUser(@PathVariable Long loanId, @RequestBody Loan loan) {
            try {
                Loan updatedLoan = loanService.updateLoan(loan, loanId);
                return ResponseEntity.ok(updatedLoan);
            } catch (RuntimeException e) {
                return ResponseEntity.notFound().build();
            }
        }

        @DeleteMapping("/{loanId}")
        public ResponseEntity<String> deleteLoan(@PathVariable Long loanId) {
            loanService.deleteLoan(loanId);
            return new ResponseEntity<String>("Deleted successfully", HttpStatus.OK);

        }

    }

