package com.cjits.service;

import com.cjits.entity.LoanApp;
import com.cjits.entity.User;

import java.util.List;

public interface LoanAppService {
    public LoanApp createLoanApp(LoanApp loanApp);
    public List<LoanApp> getAllLoanApp();
    public LoanApp findLoanAppById(long appId) throws RuntimeException;
    public LoanApp updateLoanApp(Long appId, LoanApp loanApp);
    public void deleteLoanApp(long appId);
    void save(LoanApp loanApp);
    List<LoanApp> findLoanAppList();
    LoanApp findById(Long appId);
}
