package com.cjits.service;

import com.cjits.entity.LoanRule;

import java.util.List;

public interface LoanRuleService {
    public LoanRule saveLoanRule( LoanRule l);
    public List< LoanRule> getAllLoanRules();
    public  LoanRule findLoanRuleById(long loan_rid) throws RuntimeException;
    public  LoanRule UpdateLoanRule( LoanRule l,long loan_rid) throws RuntimeException;
    public  void deleteLoanRule (long loan_rid);

}
