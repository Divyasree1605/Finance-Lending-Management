package com.cjits.service;

import com.cjits.entity.Loan;
import com.cjits.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanServiceImpl implements LoanService{
    @Autowired
    private LoanRepository loanRepository;
    @Override
    public Loan createLoan(Loan loan) {
        return loanRepository.save(loan);
    }

    @Override
    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }

    @Override
    public Loan findLoanByloanId(long loanId) throws RuntimeException {
        Optional<Loan> loan = loanRepository.findById(loanId);
        if (loan.isPresent()) {
            return loan.get();
        } else {
            throw new RuntimeException("Loan not found with id: " + loanId);
        }
    }

    @Override
    public Loan findLoanByloantypes(Loan loan, long loanId) throws RuntimeException {
        Optional<Loan> existingLoan = loanRepository.findById(loanId);
        if (existingLoan.isPresent()) {
            return existingLoan.get();
        } else {
            throw new RuntimeException("Loan not found with id: " + loanId);
        }
    }

    @Override
    public Loan updateLoan(Loan loan, long loanId) throws RuntimeException {
        Optional<Loan> existingLoan = loanRepository.findById(loanId);
        if (existingLoan.isPresent()) {
            loan.setLoanId(loanId);
            return loanRepository.save(loan);
        } else {
            throw new RuntimeException("Loan not found with id: " + loanId);
        }
    }

    @Override
    public void deleteLoan(long loanId) {
        loanRepository.deleteById(loanId);
    }
    public Optional<Loan> getLoanById(Long loanId) {
        return loanRepository.findById(loanId);
    }

    public Optional<Loan> getLoanByLoantype(String loantypes) {
        return loanRepository.findByLoantypes(loantypes);
    }
}

