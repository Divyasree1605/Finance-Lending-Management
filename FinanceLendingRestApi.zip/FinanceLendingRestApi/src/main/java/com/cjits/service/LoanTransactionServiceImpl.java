package com.cjits.service;

import com.cjits.entity.LoanTransaction;
import com.cjits.repository.LoanTransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanTransactionServiceImpl implements LoanTransactionService {

    private final LoanTransactionRepository loanTransactionRepository;

    @Autowired
    public LoanTransactionServiceImpl(LoanTransactionRepository loanTransactionRepository) {
        this.loanTransactionRepository = loanTransactionRepository;
    }

    @Override
    public LoanTransaction createLoanTransaction(LoanTransaction loanTransaction) {
        return loanTransactionRepository.save(loanTransaction);
    }

    @Override
    public List<LoanTransaction> getAllLoanTransactions() {
        return loanTransactionRepository.findAll();
    }

    @Override
    public LoanTransaction getLoanTransactionById(Long tranId) {
        Optional<LoanTransaction> optionalLoanTransaction = loanTransactionRepository.findById(tranId);
        return optionalLoanTransaction.orElse(null);
    }

    @Override
    public LoanTransaction updateLoanTransaction(Long tranId, LoanTransaction loanTransaction) {
        if (loanTransactionRepository.existsById(tranId)) {
            loanTransaction.setId(tranId);
            return loanTransactionRepository.save(loanTransaction);
        }
        return null;
    }

    @Override
    public void deleteLoanTransaction(Long tranId) {
        loanTransactionRepository.deleteById(tranId);
    }
}

