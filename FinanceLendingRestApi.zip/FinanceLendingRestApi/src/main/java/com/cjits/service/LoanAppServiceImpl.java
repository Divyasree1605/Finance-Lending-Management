package com.cjits.service;

import com.cjits.entity.LoanApp;
import com.cjits.entity.User;
import com.cjits.repository.LoanAppRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanAppServiceImpl implements LoanAppService {
    @Autowired
    private LoanAppRepository loanAppRepository;
    @Override
    public LoanApp createLoanApp(LoanApp loanApp) {
        return loanAppRepository.save(loanApp);
    }

    @Override
    public List<LoanApp> getAllLoanApp() {
        return loanAppRepository.findAll();
    }

    @Override
    public LoanApp findLoanAppById(long appId) throws RuntimeException {
        Optional<LoanApp> loanApp = loanAppRepository.findById(appId);
        if (loanApp.isPresent()) {
            return loanApp.get();
        } else {
            throw new RuntimeException("Loan Application not found with id: " + appId);
        }    }

    @Override
    public LoanApp updateLoanApp(Long appId, LoanApp loanApp) {
        Optional<LoanApp> existingLoanApp = loanAppRepository.findById(appId);
        if (existingLoanApp.isPresent()) {
            loanApp.setAppId(appId);
            return loanAppRepository.save(loanApp);
        } else {
            throw new RuntimeException("Loan Application not found with id: " + appId);
        }
    }
    @Override
    public void save(LoanApp loanApp) {
        loanAppRepository.save(loanApp);
    }
    @Override
    public List<LoanApp> findLoanAppList() {
        return loanAppRepository.findAll();
    }
    @Override
    public LoanApp findById(Long appId) {
        return loanAppRepository.findById(appId).get();
    }
    @Override
    public void deleteLoanApp(long appId) {
       loanAppRepository.deleteById(appId);
    }
    public Optional<LoanApp> getLoanAppById(Long appId) {
        return loanAppRepository.findById(appId);
    }

}
