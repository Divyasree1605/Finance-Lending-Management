package com.cjits.service;

import com.cjits.repository.LoanRuleRepository;
import com.cjits.entity.LoanRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service

public class LoanRuleServiceImpl implements LoanRuleService{
    @Autowired
    private LoanRuleRepository repo;

    @Override
    public LoanRule saveLoanRule(LoanRule l) {
        return repo.save(l);
    }

    @Override
    public List<LoanRule> getAllLoanRules() {
        return repo.findAll();
    }

    @Override
    public LoanRule findLoanRuleById(long loan_rid) throws RuntimeException {
        Optional<LoanRule> loanRule=repo.findById(loan_rid);
        if(loanRule.isPresent()){
            return loanRule.get();
        }else{
            throw  new RuntimeException("Entered id:"+loan_rid+"Not found in repositories ");
        }
    }

    @Override
    public LoanRule UpdateLoanRule(LoanRule l, long loan_rid) throws RuntimeException {
        LoanRule loanRule = repo.findById(loan_rid).get();
        if (loanRule.getLoan_rid() != 0) {
            loanRule.setLoanType(l.getLoanType());
            loanRule.setLoanRoi(l.getLoanRoi());
            loanRule.setLoanMaxEmi(l.getLoanMaxEmi());
            loanRule.setLoanPenalty(l.getLoanPenalty());


        } else {
            throw new RuntimeException("Entered LoanRule id:" + loan_rid + " Not found");
        }
        repo.save(loanRule);
        return loanRule;
    }

    @Override
    public void deleteLoanRule(long loan_rid) {
        repo.deleteById(loan_rid);

    }
}
