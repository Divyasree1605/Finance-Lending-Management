package com.cjits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserLendingRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserLendingRestApiApplication.class, args);
	}
}
